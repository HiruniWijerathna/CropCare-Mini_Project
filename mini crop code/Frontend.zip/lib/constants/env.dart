class ENVConfig {
  // Server Details
  static const String serverUrl = 'https://2192-112-134-169-85.ngrok-free.app';
}